var searchData=
[
  ['device_5fkey',['device_key',['../structwolk__ctx.html#a4b67ae9b0271566e7dae56c03053906b',1,'wolk_ctx']]],
  ['device_5fpassword',['device_password',['../structwolk__ctx.html#af6ea97768cfd0445f8b9535e0e2c354b',1,'wolk_ctx']]]
];
