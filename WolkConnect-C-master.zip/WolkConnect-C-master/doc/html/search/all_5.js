var searchData=
[
  ['milliseconds_5fsince_5flast_5fping_5fkeep_5falive',['milliseconds_since_last_ping_keep_alive',['../structwolk__ctx.html#a2d93b135a08863cedae25012a6dc8d46',1,'wolk_ctx']]],
  ['mqtt_5ftransport',['mqtt_transport',['../structwolk__ctx.html#a1f8d853e9ce94634dde14f0735207e5c',1,'wolk_ctx']]]
];
