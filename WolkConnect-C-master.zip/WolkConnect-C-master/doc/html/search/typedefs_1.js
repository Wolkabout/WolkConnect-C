var searchData=
[
  ['configuration_5fhandler_5ft',['configuration_handler_t',['../wolk__connector_8h.html#a6662d0d41546795466cc2b398d8dcb08',1,'wolk_connector.h']]],
  ['configuration_5fprovider_5ft',['configuration_provider_t',['../wolk__connector_8h.html#a64d56254d09f9e452751f32b3c5a39d3',1,'wolk_connector.h']]]
];
