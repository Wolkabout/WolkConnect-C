var searchData=
[
  ['iof',['iof',['../structwolk__ctx.html#a4b934429cb22045256b5757901fe2d66',1,'wolk_ctx']]],
  ['is_5finitialized',['is_initialized',['../structwolk__ctx.html#ae0a13a533a7c9ffc516eda95cd6ed324',1,'wolk_ctx']]],
  ['is_5fkeep_5falive_5fenabled',['is_keep_alive_enabled',['../structwolk__ctx.html#ab195921b22d85b2e46df09cca001f5e2',1,'wolk_ctx']]]
];
