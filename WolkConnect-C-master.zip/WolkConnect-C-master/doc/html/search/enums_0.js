var searchData=
[
  ['protocol_5ft',['protocol_t',['../wolk__connector_8h.html#a91e19fa4fff461493e1a41f7c7aa4e5f',1,'wolk_connector.h']]]
];
