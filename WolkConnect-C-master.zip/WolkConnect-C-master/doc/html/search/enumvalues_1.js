var searchData=
[
  ['w_5ffalse',['W_FALSE',['../wolk__connector_8h.html#a19b47d3264771c75e27cf2b2617546afa0abf1977616eb22dc9af960a3a664376',1,'wolk_connector.h']]],
  ['w_5ftrue',['W_TRUE',['../wolk__connector_8h.html#a19b47d3264771c75e27cf2b2617546afa93fad5ad6fdb521eabff2efa8934f722',1,'wolk_connector.h']]],
  ['wolk_5fversion_5fmajor',['WOLK_VERSION_MAJOR',['../wolk__connector_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba447aa6141eb0f03228f39d152985b062',1,'wolk_connector.h']]],
  ['wolk_5fversion_5fminor',['WOLK_VERSION_MINOR',['../wolk__connector_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba969b4fa8b86e732fd734fad63a85c3da',1,'wolk_connector.h']]],
  ['wolk_5fversion_5fpatch',['WOLK_VERSION_PATCH',['../wolk__connector_8h.html#a06fc87d81c62e9abb8790b6e5713c55ba747cdd3ba3df6a7a9813b05b06c698e0',1,'wolk_connector.h']]]
];
