var searchData=
[
  ['readme_2emd',['README.md',['../_r_e_a_d_m_e_8md.html',1,'']]],
  ['readme_2emd',['README.md',['../examples_2full__feature__set_2_r_e_a_d_m_e_8md.html',1,'']]]
];
