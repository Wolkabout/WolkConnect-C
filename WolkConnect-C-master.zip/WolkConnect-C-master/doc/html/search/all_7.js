var searchData=
[
  ['parser',['parser',['../structwolk__ctx.html#a823bd0528ef9d148f35d244becc4858a',1,'wolk_ctx']]],
  ['persistence',['persistence',['../structwolk__ctx.html#a9d7d83e339fcd632b0679db3f86b4293',1,'wolk_ctx']]],
  ['protocol',['protocol',['../structwolk__ctx.html#af93f257ff60dd00f34455d425207e66f',1,'wolk_ctx']]],
  ['protocol_5fjson_5fsingle',['PROTOCOL_JSON_SINGLE',['../wolk__connector_8h.html#a91e19fa4fff461493e1a41f7c7aa4e5fa9574b7cae2523f47c59e082e473223bd',1,'wolk_connector.h']]],
  ['protocol_5ft',['protocol_t',['../wolk__connector_8h.html#a91e19fa4fff461493e1a41f7c7aa4e5f',1,'wolk_connector.h']]]
];
