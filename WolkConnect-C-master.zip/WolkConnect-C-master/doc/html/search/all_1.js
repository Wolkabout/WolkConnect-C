var searchData=
[
  ['configuration_5fhandler',['configuration_handler',['../structwolk__ctx.html#a6c0926345d1d56f8fbd3cb50d8f4a804',1,'wolk_ctx']]],
  ['configuration_5fhandler_5ft',['configuration_handler_t',['../wolk__connector_8h.html#a6662d0d41546795466cc2b398d8dcb08',1,'wolk_connector.h']]],
  ['configuration_5fprovider',['configuration_provider',['../structwolk__ctx.html#a982fc36741a8c8cfb5ad3939363cebf8',1,'wolk_ctx']]],
  ['configuration_5fprovider_5ft',['configuration_provider_t',['../wolk__connector_8h.html#a64d56254d09f9e452751f32b3c5a39d3',1,'wolk_connector.h']]],
  ['connectdata',['connectData',['../structwolk__ctx.html#af63fca32333cbb2d7e2b887eff0b2461',1,'wolk_ctx']]]
];
