var searchData=
[
  ['actuation_5fhandler',['actuation_handler',['../structwolk__ctx.html#a2ab241133283e361c6822409f7ec48ca',1,'wolk_ctx']]],
  ['actuation_5fhandler_5ft',['actuation_handler_t',['../wolk__connector_8h.html#acde87869e807b1774680f3f2b5b04e2f',1,'wolk_connector.h']]],
  ['actuator_5freferences',['actuator_references',['../structwolk__ctx.html#aa2127e8414d0d9c6214343891f4a322f',1,'wolk_ctx']]],
  ['actuator_5fstatus_5fprovider',['actuator_status_provider',['../structwolk__ctx.html#aee7f3ef8dbcfd4f8a3817ef26a1629f6',1,'wolk_ctx']]],
  ['actuator_5fstatus_5fprovider_5ft',['actuator_status_provider_t',['../wolk__connector_8h.html#af3e8919a04a293972b64605557287537',1,'wolk_connector.h']]]
];
