var searchData=
[
  ['recv_5ffunc_5ft',['recv_func_t',['../wolk__connector_8h.html#ac6f167182b7b63052d13946a6c4fba06',1,'wolk_connector.h']]]
];
