var searchData=
[
  ['send_5ffunc_5ft',['send_func_t',['../wolk__connector_8h.html#a830662686699e21c1280f63d2ec80faf',1,'wolk_connector.h']]],
  ['sock',['sock',['../structwolk__ctx.html#a7b2318c99408cdafb7ede7f5d472e100',1,'wolk_ctx']]]
];
