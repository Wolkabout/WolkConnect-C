var searchData=
[
  ['protocol_5fjson_5fsingle',['PROTOCOL_JSON_SINGLE',['../wolk__connector_8h.html#a91e19fa4fff461493e1a41f7c7aa4e5fa9574b7cae2523f47c59e082e473223bd',1,'wolk_connector.h']]]
];
