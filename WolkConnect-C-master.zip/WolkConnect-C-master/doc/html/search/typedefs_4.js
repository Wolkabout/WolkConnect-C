var searchData=
[
  ['wolk_5fbool_5ft',['WOLK_BOOL_T',['../wolk__connector_8h.html#a8b01c4c1e6c1d8d91197fb49c642c4ef',1,'wolk_connector.h']]],
  ['wolk_5fctx_5ft',['wolk_ctx_t',['../wolk__connector_8h.html#ac2ef8e5728bb7f6b92489fb48d3cf154',1,'wolk_connector.h']]],
  ['wolk_5ferr_5ft',['WOLK_ERR_T',['../wolk__connector_8h.html#a5e8017d60f3753b4d489aeb7d3392641',1,'wolk_connector.h']]]
];
