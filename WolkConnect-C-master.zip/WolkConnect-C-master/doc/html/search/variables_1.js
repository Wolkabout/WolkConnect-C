var searchData=
[
  ['configuration_5fhandler',['configuration_handler',['../structwolk__ctx.html#a6c0926345d1d56f8fbd3cb50d8f4a804',1,'wolk_ctx']]],
  ['configuration_5fprovider',['configuration_provider',['../structwolk__ctx.html#a982fc36741a8c8cfb5ad3939363cebf8',1,'wolk_ctx']]],
  ['connectdata',['connectData',['../structwolk__ctx.html#af63fca32333cbb2d7e2b887eff0b2461',1,'wolk_ctx']]]
];
